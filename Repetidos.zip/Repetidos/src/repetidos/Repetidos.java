package repetidos;
import java.util.Scanner;
public class Repetidos {
    public static void main(String[] args) {
        Scanner teclado=new Scanner(System.in);
        int numeroNumeros;
        int numeroSinRepetir;
        int[] numeros;
        int[] sinRepetir;
        System.out.println("Dime cuantos números vas a meter: ");
        numeroNumeros=teclado.nextInt();
        numeros=new int[numeroNumeros];
        sinRepetir=new int[numeroNumeros];
        leerNumeros(numeros);
        numeroSinRepetir=eliminarRepetidos(numeros, sinRepetir); 
         mostrar(numeroSinRepetir, sinRepetir);
    }
    public static void leerNumeros(int[] numeros){
        Scanner teclado=new Scanner(System.in);
        int a;
        int cont=0;
        do{
            System.out.println("Dime el número: ");
            a=teclado.nextInt();
            if (a>=10 && a<=100){
                numeros[cont]=a;
                cont++;
            }
            else {
                System.out.println("Número menor de 10 o mayor de 100");
            }
        } while (cont<numeros.length);
    }
    public static int eliminarRepetidos(int[] numeros, int[] sinRepetir){
        boolean repetido=false;
        int ii=0;
        for (int i=0;i<numeros.length;i++){
            for(int j=i+1;j<numeros.length;j++){
                if(numeros[i]==numeros[j]){
                    repetido=true;
                }
            }
            if (repetido==false){
                sinRepetir[ii++]=numeros[i];
            }
            else {
                repetido=false;
            }
        }
        return ii;
    }
    public static void mostrar (int numeroSinRepetir,int[] sinRepetir){
        System.out.println("Números sin repetir");
        for(int i=0;i<numeroSinRepetir;i++){
            System.out.println(sinRepetir[i]);
        }
        
    }
    
}
