/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instituto;


public class Modulo {
    private String nombre;
    private String ciclo;
    private int curso;
    private double [] notas;
    private int cNotas;  // contador de notas
    
    public Modulo(String n, String c, int cu, int nNota){
       nombre=n;
       ciclo=c;
       curso=cu;
       notas= new double[nNota];
       cNotas=0;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCiclo() {
        return ciclo;
    }

    public int getCurso() {
        return curso;
    }

    public int getcNotas() {
        return cNotas;
    }
    public int getLength(){
        return notas.length;
    }
    public void evaluar(double nota){
        if(cNotas<notas.length){
        notas[cNotas]=nota;
        cNotas++;
        }
         else{
            System.err.println("no pudo evaluarse");
        }
    }
    public void cambiar(double nota, int examen){
        if(examen<=cNotas){
            notas[examen-1]=nota;
        }
        else{
            System.err.println("no pudo cambiarse la nota");
        }
    }
    public double promedio(){
        double suma=0;
        for(int i=0;i<cNotas;i++){
            suma+=notas[i];
        }
        return suma/cNotas;
    }
    public double mediaPonderada(double[]ponderacion){
        double suma=0; //suma de las ponderaciones
        double media=0;
        if(ponderacion.length>=cNotas){
            for(int i=0;i<cNotas;i++){
                suma+=ponderacion[i];
            }
            if(suma==1){
                for(int i=0;i<cNotas;i++){
                    media+=ponderacion[i]*notas[i];
                }
            }
                else{
                        media=-1;
                    }
        }
                else{
                    media=-1;    
                    }
                return media;
            }
    public double [] getNotas(){
        return notas;
    }
        }
    


