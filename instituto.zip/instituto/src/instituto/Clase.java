/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instituto;

/**
 *
 * @author profesor
 */
public class Clase {
    final int CUPO=30;
    private String centro;
    private String ciclo;
    private int curso;
    private Alumno[]alumnado;
    private int cAlumnos;
    
    public Clase(String ce,String ci,int cu){
        centro=ce;
        ciclo=ci;
        curso=cu;
        alumnado=new Alumno[CUPO];
        cAlumnos=0;
    }
    public void matricular(Alumno a){
        if(cAlumnos<CUPO){
        alumnado[cAlumnos++]=a;
        }
    }
    public void baja(String n){
        boolean encontrado=false;
        int posicion=-1;
        for(int i=0;i<cAlumnos&&!encontrado;i++){
            if(n.equals(alumnado[i].getNombre())){
                encontrado=true;
                posicion=i;
            }
        }
        if(encontrado){
            cAlumnos--; //decrementamos numero de alumnos
            for( ;posicion<cAlumnos;posicion++){ //
                alumnado[posicion]=alumnado[posicion+1]; // si hay cinco posiciones y eliminamos al que esta en la posicon 2, la posicion dos pasa a señalar a quie estaba en la 3
            }
        }
    }
}
