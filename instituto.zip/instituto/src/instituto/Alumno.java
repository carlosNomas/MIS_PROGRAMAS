/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instituto;

/**
 *
 * @author profesor
 */
public class Alumno {
    String nombre;
    int edad;
    char sexo;
    Modulo[]misModulos;
    
    public Alumno(String n,int e,char s,Modulo[]mod){
        nombre=n;
        edad=e;
        sexo=s;
        misModulos=new Modulo[mod.length];
        for(int i=0;i<misModulos.length;i++){
            misModulos[i]=new Modulo(mod[i].getNombre(),mod[i].getCiclo(),mod[i].getCurso(),mod[i].getLength());
        }
        
    }

    public String getNombre() {
        return nombre;
    }
    public double media(){
        double suma=0;
        for(int i=0;i<misModulos.length;i++){
            suma+=misModulos[i].promedio();
        }
        return suma/misModulos.length;
    }
    public void verNotaMasAlta(){  //nota mas alta de cada alumno
        double notaMasAlta=0;
        int modulo=0, examen=0;
        for(int i=0;i<misModulos.length;i++){
            double[]notasModulo;
            int contadorNotas;
            notasModulo=misModulos[i].getNotas();
            contadorNotas=misModulos[i].getcNotas();
            for(int j=0;j<contadorNotas;j++){
                if(notasModulo[j]>notaMasAlta){
                    notaMasAlta=notasModulo[j];
                    modulo=i;
                    examen=j;
                }
            }
        }
        System.out.println("La primera nota mas alta de "+nombre+"es"+notaMasAlta);
        System.out.println("Se obtuvo en "+misModulos[modulo].getNombre()+"en el examen"+(examen+1)); //nombre del modulo donde obtuvo la nota mas alta
    }
}
