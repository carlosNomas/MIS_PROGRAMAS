package craps;
public class Craps {
    public static void main(String[] args) {
        int tirada=craps();
        if (tirada<0){
            System.out.println("Has perdido a la "+-tirada+" tirada");
        }
        else {
            if (tirada>0){
                System.out.println("Has ganado a la "+tirada+" tirada");
            }
        }
    }
    public static int craps(){
        int resultado=0,suma, rondaFinal;
        suma=tirarDados();
        if(suma==7 || suma==11){
            resultado=1;
        }
        else {
            if (suma==2 || suma==3 || suma==12){
                resultado=-1;
            }
            else {
                int primeraTirada=suma;
                rondaFinal=1;
                do {
                    suma=tirarDados();
                    rondaFinal++;
                } while(suma!=7 && suma!=primeraTirada);
                if (suma==7){
                    resultado=+rondaFinal;
                }
                else {
                    resultado=rondaFinal;
                }
            }
        }
        return resultado;
    }
    public static int tirarDados(){
        int dado1, dado2, suma;
        dado1=(int)(Math.random()*6+1);
        dado2=(int)(Math.random()*6+1);
        suma=dado1+dado2;
        return suma;
    }
}
