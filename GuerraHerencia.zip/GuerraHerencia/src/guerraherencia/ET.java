/*
Clase heredera de Marciano
 */
package guerraherencia;

public final class ET extends Marciano {
    public ET(){
        super(5);
    }
    public void disparar(){
        for (int i=0;i<disparos.length;i++){
            disparos[i]+=3;
        }
    }
}
