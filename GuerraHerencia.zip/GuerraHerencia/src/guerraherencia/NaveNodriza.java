package guerraherencia;
public class NaveNodriza {
    private Marciano[] marcianos;//Declaramos el array
    int contador=0;
    public NaveNodriza(int numMarcianos){
        int aleatorio;
        marcianos=new Marciano[numMarcianos];
        for(int i=0;i<marcianos.length;i++){
            aleatorio=(int)(Math.random()*5);
            if (aleatorio==4){
                marcianos[i]=new Alien();
            }
            else {
                marcianos[i]=new ET();    
            }
            
        }
    }
    public void disparar(){

        for (int i=0;i<marcianos.length;i++){
            marcianos[i].disparar();
            contador=contador+marcianos[i].obtenerDisparos();
        }
    }
    public int getDisparos(){
        return contador;
    }
    public void mostrarInformacion(){
        for (int i=0;i<marcianos.length;i++){
            if (marcianos[i] instanceof ET==true){
                System.out.println("El marciano (ET) "+marcianos[i].getIdentidad()+" ha disparado "+marcianos[i].obtenerDisparos()+" veces");
            }
            else {
                if (marcianos[i] instanceof Alien==true){
                    System.out.println("El marciano (Alien) "+marcianos[i].getIdentidad()+" ha disparado "+marcianos[i].obtenerDisparos()+" veces");
                }
                else {
                    System.out.println("El marciano "+marcianos[i].getIdentidad()+" ha disparado "+marcianos[i].obtenerDisparos()+" veces");
                }
            }
        }
    }
}
