package guerraherencia;
public class GuerraHerencia {
    public static void main(String[] args) {
        int sumaDisparos=0;
        NaveNodriza nave1, nave2;
        nave1=new NaveNodriza(15);
        nave2=new NaveNodriza(15);
        nave1.disparar();
        nave2.disparar();
        System.out.println("Información de la nave1: ");
        nave1.mostrarInformacion();
        System.out.println("Información de la nave 2: ");
        nave2.mostrarInformacion();
        if (nave1.getDisparos()>nave2.getDisparos()){
            System.out.println("La nave 1 ha ganado");
        }
        else {
            if (nave1.getDisparos()<nave2.getDisparos()){
                System.out.println("La nave 2 ha ganado");
            }
            else {
                System.out.println("Empate");
            }
        }
        System.out.println("La nave 1 ha disparado " + nave1.getDisparos() + " disparos.");
        System.out.println("La nave 2 ha disparado " + nave2.getDisparos() + " disparos.");
        sumaDisparos=nave1.getDisparos()+nave2.getDisparos();
        System.out.println("El total de disparos es de "+sumaDisparos+" disparos del acto de la disparasion.");
    }
    
}
